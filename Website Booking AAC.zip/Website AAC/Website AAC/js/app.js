// Helper: Format Rupiah
function formatRupiah(num) {
  return 'Rp ' + Number(num).toLocaleString('id-ID');
}

// Helper: Format Tanggal Indonesia
function formatDateID(dateStr) {
  if (!dateStr) return '-';
  const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  const [y, m, d] = dateStr.split('-').map(Number);
  return `${d} ${months[m - 1]} ${y}`;
}

// Helper: Expand booking dates (termasuk multi-hari)
function getBookingCoveredDates(b) {
  const dates = [];
  const start = new Date(b.date + 'T00:00:00');
  const totalDays = b.days || 1;
  for (let i = 0; i < totalDays; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    dates.push(`${yyyy}-${mm}-${dd}`);
  }
  return dates;
}

// Helper: Get all active bookings on a specific date
function getBookingsOnDate(dateStr) {
  return bookings.filter(b => b.status !== 'Ditolak' && getBookingCoveredDates(b).includes(dateStr));
}

// Helper: Toast notification
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const colors = {
    success: 'bg-emerald-700 text-white border-emerald-500',
    warning: 'bg-amber-600 text-white border-amber-400',
    error: 'bg-rose-700 text-white border-rose-500',
    info: 'bg-[#1A365D] text-white border-[#D69E2E]'
  };
  const toast = document.createElement('div');
  toast.className = `pointer-events-auto px-4 py-3 rounded-xl shadow-lg border text-xs font-semibold flex items-center justify-between gap-3 transition-all transform translate-y-0 ${colors[type] || colors.info}`;
  toast.innerHTML = `<span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ==================== NAVIGATION TAB SWITCHER ====================
function switchTab(tabId) {
  document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
  document.getElementById(`tab-${tabId}`).classList.remove('hidden');

  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.remove('tab-active');
    btn.classList.add('text-slate-600', 'hover:bg-slate-100');
  });

  const activeBtn = document.getElementById(`nav-${tabId}`);
  if (activeBtn) {
    activeBtn.classList.add('tab-active');
    activeBtn.classList.remove('text-slate-600', 'hover:bg-slate-100');
  }

  if (tabId === 'beranda') renderCalendar();
  if (tabId === 'pemohon') renderPemohonDashboard();
  if (tabId === 'admin') renderAdminDashboard();
  const scrollBehavior = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth';
  window.scrollTo({ top: 0, behavior: scrollBehavior });
}

// ==================== TAB 1: CALENDAR & ROOM INSPECTOR ====================
function changeMonth(delta) {
  currentMonth += delta;
  if (currentMonth > 11) {
    currentMonth = 0;
    currentYear++;
  } else if (currentMonth < 0) {
    currentMonth = 11;
    currentYear--;
  }
  renderCalendar();
}

function renderCalendar() {
  const monthNames = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  document.getElementById('calendar-month-label').textContent = `${monthNames[currentMonth]} ${currentYear}`;

  const grid = document.getElementById('calendar-grid');
  grid.innerHTML = '';

  const firstDay = new Date(currentYear, currentMonth, 1).getDay();
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

  // Empty cells before 1st day
  for (let i = 0; i < firstDay; i++) {
    const empty = document.createElement('div');
    empty.className = 'h-12 sm:h-14 rounded-xl bg-slate-50/60';
    grid.appendChild(empty);
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const dayBookings = getBookingsOnDate(dateStr);

    let statusClass = 'bg-emerald-50/80 border-emerald-200 text-emerald-900 hover:bg-emerald-100';
    let dotColor = 'bg-emerald-500';
    let label = 'Kosong';

    if (dayBookings.length > 0) {
      const hasCampusBlock = dayBookings.some(b => b.isCampusBlock);
      const hasBooked = dayBookings.some(b => b.status === 'Booked');
      const lockedZonesCount = new Set(dayBookings.flatMap(b => b.zones)).size;

      if (hasCampusBlock || lockedZonesCount >= 4) {
        statusClass = 'bg-rose-50 border-rose-300 text-rose-900 hover:bg-rose-100';
        dotColor = 'bg-rose-600';
        label = hasCampusBlock ? 'Agenda USK' : 'Penuh';
      } else if (hasBooked) {
        statusClass = 'bg-amber-50 border-amber-300 text-amber-900 hover:bg-amber-100';
        dotColor = 'bg-amber-500';
        label = `${dayBookings.length} Acara`;
      } else {
        statusClass = 'bg-amber-50/80 border-amber-200 text-amber-800 hover:bg-amber-100';
        dotColor = 'bg-amber-400';
        label = 'Pending';
      }
    }

    const isSelected = dateStr === selectedDateStr;
    const selectedRing = isSelected ? 'ring-2 ring-[#1A365D] ring-offset-1 font-extrabold' : '';

    const cell = document.createElement('button');
    cell.type = 'button';
    cell.onclick = () => selectCalendarDate(dateStr);
    cell.className = `h-12 sm:h-14 rounded-xl border p-1.5 flex flex-col justify-between items-start transition text-left ${statusClass} ${selectedRing}`;
    cell.innerHTML = `
      <div class="w-full flex items-center justify-between">
        <span class="text-xs sm:text-sm font-bold">${day}</span>
        <span class="w-2 h-2 rounded-full ${dotColor}"></span>
      </div>
      <span class="text-[10px] leading-tight truncate w-full opacity-85 hidden sm:block">${label}</span>
    `;
    grid.appendChild(cell);
  }

  inspectDate(selectedDateStr);
}

function selectCalendarDate(dateStr) {
  selectedDateStr = dateStr;
  renderCalendar();
}

function inspectDate(dateStr) {
  document.getElementById('selected-date-title').textContent = formatDateID(dateStr);
  const dayBookings = getBookingsOnDate(dateStr);
  const badge = document.getElementById('selected-date-badge');
  const eventsContainer = document.getElementById('selected-date-events');
  const zonesContainer = document.getElementById('room-zones-status');

  const lockedZonesSet = new Set();
  dayBookings.forEach(b => b.zones.forEach(z => lockedZonesSet.add(z)));

  if (dayBookings.length === 0) {
    badge.className = 'px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800';
    badge.textContent = 'Tersedia Semua Zona';
    eventsContainer.innerHTML = `
      <div class="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
        Seluruh ruangan di Gedung AAC Dayan Dawood tersedia untuk pemesanan paket maupun ruangan satuan pada tanggal ini.
      </div>
    `;
  } else {
    const isFull = lockedZonesSet.size >= 4 || dayBookings.some(b => b.isCampusBlock);
    badge.className = isFull
      ? 'px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-100 text-rose-800'
      : 'px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800';
    badge.textContent = isFull ? 'Terkunci Penuh' : 'Sebagian Zona Tersedia';

    eventsContainer.innerHTML = dayBookings.map(b => `
      <div class="p-3 rounded-xl border ${b.status === 'Booked' ? 'bg-rose-50/70 border-rose-200' : 'bg-amber-50/70 border-amber-200'} text-xs space-y-1">
        <div class="flex items-center justify-between gap-2">
          <span class="font-bold text-slate-800">${b.eventName}</span>
          <span class="px-2 py-0.5 rounded-full text-[10px] font-bold ${b.status === 'Booked' ? 'bg-rose-600 text-white' : 'bg-amber-500 text-white'}">${b.status}</span>
        </div>
        <div class="text-slate-600">Penyelenggara: <strong>${b.orgName}</strong> (${b.applicantType})</div>
        <div class="text-slate-500">Zona Terkunci: <span class="font-semibold text-slate-700">${b.zones.join(', ')}</span></div>
      </div>
    `).join('');
  }

  // Render 8 Sub-Zones Status
  zonesContainer.innerHTML = ALL_ZONES.map(zone => {
    const isLocked = lockedZonesSet.has(zone);
    return `
      <div class="flex items-center justify-between px-3 py-2 rounded-lg border text-xs ${isLocked ? 'bg-rose-50/60 border-rose-200 text-rose-800' : 'bg-emerald-50/60 border-emerald-200 text-emerald-800'}">
        <span class="font-medium truncate">${zone}</span>
        <span class="font-bold text-[10px] uppercase px-1.5 py-0.5 rounded ${isLocked ? 'bg-rose-200/70 text-rose-900' : 'bg-emerald-200/70 text-emerald-900'}">
          ${isLocked ? 'Terkunci' : 'Kosong'}
        </span>
      </div>
    `;
  }).join('');
}

function bookSelectedDate() {
  document.getElementById('form-date').value = selectedDateStr;
  switchTab('booking');
  calculateBookingCost();
  showToast(`Tanggal ${formatDateID(selectedDateStr)} diterapkan ke formulir booking.`, 'info');
}

// ==================== TAB 2: PRICELIST INTERACTIVE ====================
function renderPricelist(filterCat = 'ALL') {
  const grid = document.getElementById('pricelist-grid');
  const items = filterCat === 'ALL' ? PRICELIST_DATA : PRICELIST_DATA.filter(i => i.category === filterCat);

  grid.innerHTML = items.map(item => {
    const priceDisplay = item.isConcert
      ? `<div class="space-y-0.5">
           <div class="text-base font-extrabold text-[#1A365D]">${formatRupiah(item.priceH1)} <span class="text-xs font-normal text-slate-500">/ jam (H-1)</span></div>
           <div class="text-base font-extrabold text-[#2B6CB0]">${formatRupiah(item.priceDay)} <span class="text-xs font-normal text-slate-500">/ jam (Hari-H)</span></div>
         </div>`
      : `<div class="text-xl font-extrabold text-[#1A365D]">${formatRupiah(item.price)} <span class="text-xs font-medium text-slate-500">/ ${item.unit}</span></div>`;

    return `
      <div class="rounded-2xl border border-slate-200 bg-white p-5 flex flex-col justify-between hover:border-[#2B6CB0] hover:shadow-md transition">
        <div>
          <div class="flex items-center justify-between gap-2 mb-2">
            <span class="px-2.5 py-1 rounded-lg bg-blue-50 text-[#1A365D] text-[11px] font-bold">${item.categoryLabel}</span>
            <span class="text-[11px] font-semibold text-slate-400">Satuan: ${item.unit}</span>
          </div>
          <h3 class="text-base font-bold text-slate-800 leading-snug">${item.name}</h3>
          <div class="mt-3">
            <div class="text-[11px] text-slate-400 font-semibold uppercase mb-1">Cakupan Zona Ruangan:</div>
            <div class="flex flex-wrap gap-1">
              ${item.zones.map(z => `<span class="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[11px] font-medium">${z}</span>`).join('')}
            </div>
          </div>
        </div>

        <div class="mt-5 pt-4 border-t border-slate-100 space-y-3">
          ${priceDisplay}
          <button onclick="selectPackageToBook('${item.category}', '${item.id}')" class="w-full py-2.5 px-4 rounded-xl bg-[#1A365D] hover:bg-[#D69E2E] hover:text-slate-950 text-white text-xs font-bold transition flex items-center justify-center gap-1.5">
            <span>Pesan Paket Ini</span>
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
          </button>
        </div>
      </div>
    `;
  }).join('');
}

function filterPricelist(cat) {
  document.querySelectorAll('.pl-filter-btn').forEach(btn => {
    if (btn.dataset.cat === cat) {
      btn.className = 'pl-filter-btn px-4 py-2 rounded-xl text-xs sm:text-sm font-bold bg-[#1A365D] text-white shadow-sm transition';
    } else {
      btn.className = 'pl-filter-btn px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200 transition';
    }
  });
  renderPricelist(cat);
}

function selectPackageToBook(category, packageId) {
  document.getElementById('form-category').value = category;
  onCategoryChange();
  document.getElementById('form-package').value = packageId;
  calculateBookingCost();
  switchTab('booking');
  showToast('Paket berhasil dipilih ke formulir pemesanan.', 'success');
}

// ==================== TAB 3: BOOKING FORM & CALCULATOR ====================
function onCategoryChange() {
  const cat = document.getElementById('form-category').value;
  const pkgSelect = document.getElementById('form-package');
  const filtered = PRICELIST_DATA.filter(p => p.category === cat);

  pkgSelect.innerHTML = filtered.map(p => {
    const label = p.isConcert
      ? `${p.name} (${formatRupiah(p.priceH1)}/jam H-1 & ${formatRupiah(p.priceDay)}/jam Hari-H)`
      : `${p.name} — ${formatRupiah(p.price)}/${p.unit}`;
    return `<option value="${p.id}">${label}</option>`;
  }).join('');

  const isConcert = cat === 'Komersil';
  document.getElementById('duration-days-wrapper').classList.toggle('hidden', isConcert);
  const concertWrapper = document.getElementById('duration-concert-wrapper');
  if (isConcert) {
    const concertPackage = filtered.find(p => p.isConcert);
    document.getElementById('form-hours-h1-rate').textContent = `Tarif: ${formatRupiah(concertPackage.priceH1)} / jam`;
    document.getElementById('form-hours-h-rate').textContent = `Tarif: ${formatRupiah(concertPackage.priceDay)} / jam`;
    concertWrapper.classList.remove('hidden');
    concertWrapper.classList.add('grid');
  } else {
    concertWrapper.classList.add('hidden');
    concertWrapper.classList.remove('grid');
  }

  calculateBookingCost();
}

function calculateBookingCost() {
  const applicantType = document.querySelector('input[name="applicantType"]:checked').value;
  const cat = document.getElementById('form-category').value;
  const pkgId = document.getElementById('form-package').value;
  const pkg = PRICELIST_DATA.find(p => p.id === pkgId) || PRICELIST_DATA[0];
  const dateVal = document.getElementById('form-date').value;

  let total = 0;
  let durationText = '';
  let daysToCheck = 1;

  if (pkg.isConcert) {
    const h1 = Math.max(0, parseInt(document.getElementById('form-hours-h1').value) || 0);
    const h = Math.max(1, parseInt(document.getElementById('form-hours-h').value) || 1);
    total = (h1 * pkg.priceH1) + (h * pkg.priceDay);
    durationText = `H-1: ${h1} Jam + Hari-H: ${h} Jam`;
    daysToCheck = 1;
  } else {
    const days = Math.max(1, parseInt(document.getElementById('form-days').value) || 1);
    total = pkg.price * days;
    durationText = `${days} Hari`;
    daysToCheck = days;
  }

  // Update Summary Card
  document.getElementById('summary-applicant-badge').textContent = applicantType;
  document.getElementById('summary-category').textContent = pkg.categoryLabel;
  document.getElementById('summary-package').textContent = pkg.name;
  document.getElementById('summary-date').textContent = formatDateID(dateVal);
  document.getElementById('summary-duration').textContent = durationText;
  document.getElementById('summary-total-price').textContent = formatRupiah(total);

  document.getElementById('summary-locked-zones').innerHTML = pkg.zones.map(z =>
    `<span class="px-2 py-0.5 rounded bg-white/15 text-white text-[11px] font-medium">${z}</span>`
  ).join('');

  document.getElementById('summary-internal-note').classList.toggle('hidden', applicantType !== 'Internal USK');

  // Check Smart Room Locking Conflicts
  checkScheduleConflict(dateVal, daysToCheck, pkg.zones);
}

function checkScheduleConflict(startDateStr, days, requestedZones) {
  const alertBox = document.getElementById('conflict-alert');
  const submitBtn = document.getElementById('submit-booking-btn');
  if (!startDateStr) {
    alertBox.classList.add('hidden');
    return;
  }

  const tempBooking = { date: startDateStr, days: days };
  const checkDates = getBookingCoveredDates(tempBooking);
  let conflicts = [];

  checkDates.forEach(dStr => {
    const existing = getBookingsOnDate(dStr);
    existing.forEach(eb => {
      const overlapZones = eb.zones.filter(z => requestedZones.includes(z));
      if (overlapZones.length > 0) {
        conflicts.push({
          date: dStr,
          eventName: eb.eventName,
          status: eb.status,
          overlapZones
        });
      }
    });
  });

  if (conflicts.length > 0) {
    const c = conflicts[0];
    alertBox.className = 'rounded-xl p-3.5 border bg-rose-50 border-rose-300 text-rose-900 text-xs leading-relaxed';
    alertBox.innerHTML = `
      <div class="font-bold flex items-center gap-1.5 text-rose-700">
        <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
        Peringatan Smart Room Locking: Jadwal Bentrok!
      </div>
      <p class="mt-1">Pada <strong>${formatDateID(c.date)}</strong>, zona <strong>${c.overlapZones.join(', ')}</strong> sudah terkunci oleh agenda <em>"${c.eventName}"</em> (${c.status}). Silakan pilih tanggal lain atau ruangan terpisah (misal: Flamboyan Lt. II/III).</p>
    `;
    submitBtn.disabled = true;
    submitBtn.classList.add('opacity-50', 'cursor-not-allowed');
  } else {
    alertBox.className = 'rounded-xl p-3.5 border bg-emerald-50 border-emerald-200 text-emerald-900 text-xs leading-relaxed';
    alertBox.innerHTML = `
      <div class="font-bold text-emerald-800 flex items-center gap-1.5">
        <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        Jadwal & Zona Ruangan Tersedia
      </div>
      <p class="mt-0.5">Tidak ada bentrok jadwal pada tanggal tersebut. Sistem akan mengunci zona terpilih secara otomatis setelah pengajuan dikirim.</p>
    `;
    submitBtn.disabled = false;
    submitBtn.classList.remove('opacity-50', 'cursor-not-allowed');
  }
}

let uploadedFileName = '';
function handleFileSelect(input) {
  if (!input.files || !input.files[0]) return;

  const file = input.files[0];
  if (!file.name.toLowerCase().endsWith('.pdf') || file.size > 5 * 1024 * 1024) {
    input.value = '';
    uploadedFileName = '';
    document.getElementById('file-label-text').textContent = 'Klik untuk pilih file Surat_Permohonan.pdf';
    showToast('Pilih file PDF dengan ukuran maksimal 5 MB.', 'error');
    return;
  }

  uploadedFileName = file.name;
  document.getElementById('file-label-text').textContent = `Terlampir: ${uploadedFileName}`;
}

function submitBooking(e) {
  e.preventDefault();
  if (!uploadedFileName) {
    showToast('Lampirkan surat permohonan dalam format PDF terlebih dahulu.', 'error');
    return;
  }

  const applicantType = document.querySelector('input[name="applicantType"]:checked').value;
  const pkgId = document.getElementById('form-package').value;
  const pkg = PRICELIST_DATA.find(p => p.id === pkgId);
  const dateVal = document.getElementById('form-date').value;
  const eventName = document.getElementById('form-event-name').value.trim();
  const orgName = document.getElementById('form-org-name').value.trim();

  let total = 0;
  let days = 1;
  let durationText = '';

  if (pkg.isConcert) {
    const h1 = Math.max(0, parseInt(document.getElementById('form-hours-h1').value) || 0);
    const h = Math.max(1, parseInt(document.getElementById('form-hours-h').value) || 1);
    total = (h1 * pkg.priceH1) + (h * pkg.priceDay);
    durationText = `H-1 (${h1} Jam) & Hari-H (${h} Jam)`;
  } else {
    days = Math.max(1, parseInt(document.getElementById('form-days').value) || 1);
    total = pkg.price * days;
    durationText = `${days} Hari`;
  }

  const newBooking = {
    id: `BK-2026-00${bookings.length + 1}`,
    eventName,
    orgName,
    applicantType,
    category: pkg.category,
    packageName: pkg.name,
    zones: [...pkg.zones],
    date: dateVal,
    days,
    durationText,
    totalCost: total,
    status: 'Menunggu Verifikasi',
    fileName: uploadedFileName,
    paymentProof: null,
    isCampusBlock: false
  };

  bookings.unshift(newBooking);
  updateNavBadges();
  showToast('Pengajuan berhasil dikirim! Silakan pantau status di Dashboard Pemohon.', 'success');

  // Reset inputs lightly & switch to applicant dashboard
  document.getElementById('form-event-name').value = '';
  switchTab('pemohon');
}

// ==================== TAB 4: DASHBOARD PEMOHON ====================
function renderPemohonDashboard() {
  const container = document.getElementById('pemohon-bookings-list');
  const userBookings = bookings.filter(b => !b.isCampusBlock);

  if (userBookings.length === 0) {
    container.innerHTML = `<div class="text-center py-10 text-sm text-slate-500">Belum ada pengajuan pemesanan.</div>`;
    return;
  }

  container.innerHTML = userBookings.map(b => {
    let statusBadge = '';
    let actionArea = '';

    if (b.status === 'Menunggu Verifikasi') {
      statusBadge = `<span class="px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300">Menunggu Verifikasi Admin</span>`;
      actionArea = `<span class="text-xs text-slate-500 italic">Admin BUK sedang memeriksa surat permohonan (${b.fileName})</span>`;
    } else if (b.status === 'Menunggu Pembayaran') {
      statusBadge = `<span class="px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-[#1A365D] border border-blue-300">Disetujui — Menunggu Pembayaran</span>`;
      actionArea = `<span class="text-xs text-slate-500">Tindak lanjut pembayaran dilakukan langsung dengan pengelola Gedung AAC.</span>`;
    } else if (b.status === 'Booked') {
      statusBadge = `<span class="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">Terkonfirmasi / Booked</span>`;
      actionArea = `
        <button onclick="openReservationSummary('${b.id}')" class="px-4 py-2 rounded-xl bg-[#1A365D] hover:bg-[#2B6CB0] text-white text-xs font-bold shadow-sm transition flex items-center gap-1.5">
          <svg class="w-4 h-4 text-[#F6E05E]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/></svg>
          Lihat Ringkasan Reservasi
        </button>
      `;
    } else if (b.status === 'Ditolak') {
      statusBadge = `<span class="px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300">Ditolak</span>`;
      actionArea = `<span class="text-xs text-rose-600 font-medium">Pengajuan ditolak oleh pengelola gedung.</span>`;
    }

    return `
      <div class="rounded-2xl border border-slate-200 p-5 hover:border-slate-300 transition bg-slate-50/40 space-y-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div class="flex flex-wrap items-center gap-2">
              <span class="text-xs font-mono font-bold text-[#2B6CB0]">#${b.id}</span>
              <span class="px-2 py-0.5 rounded bg-slate-200 text-slate-700 text-[11px] font-semibold">${b.applicantType}</span>
              <span class="px-2 py-0.5 rounded bg-blue-50 text-[#1A365D] text-[11px] font-semibold">${b.category}</span>
            </div>
            <h3 class="text-base sm:text-lg font-bold text-[#1A365D] mt-1">${b.eventName}</h3>
            <p class="text-xs text-slate-600">Pemohon: <strong>${b.orgName}</strong></p>
          </div>
          <div class="self-start md:self-center">${statusBadge}</div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white p-3.5 rounded-xl border border-slate-200/80 text-xs">
          <div>
            <span class="text-slate-400 block">Paket / Ruangan</span>
            <strong class="text-slate-800">${b.packageName}</strong>
          </div>
          <div>
            <span class="text-slate-400 block">Tanggal & Durasi</span>
            <strong class="text-slate-800">${formatDateID(b.date)} (${b.durationText})</strong>
          </div>
          <div>
            <span class="text-slate-400 block">Estimasi Tarif</span>
            <strong class="text-[#1A365D] text-sm">${formatRupiah(b.totalCost)}</strong>
          </div>
        </div>

        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
          <div class="text-xs text-slate-500">
            Dokumen: <span class="underline text-slate-700">${b.fileName}</span>
            ${b.paymentProof ? ` • Bayar: <span class="text-emerald-700 font-semibold">${b.paymentProof}</span>` : ''}
          </div>
          <div>${actionArea}</div>
        </div>
      </div>
    `;
  }).join('');
}

// ==================== TAB 5: DASHBOARD ADMIN ====================
function renderAdminDashboard() {
  // Update KPI Stats
  document.getElementById('stat-total').textContent = bookings.length;
  document.getElementById('stat-pending').textContent = bookings.filter(b => b.status === 'Menunggu Verifikasi' || b.status === 'Menunggu Pembayaran').length;
  document.getElementById('stat-booked').textContent = bookings.filter(b => b.status === 'Booked').length;

  const revenue = bookings
    .filter(b => b.status === 'Booked' && b.applicantType === 'Eksternal / Umum')
    .reduce((sum, b) => sum + b.totalCost, 0);
  document.getElementById('stat-revenue').textContent = formatRupiah(revenue);

  // Render Bookings Management List
  const adminList = document.getElementById('admin-bookings-list');
  adminList.innerHTML = bookings.map(b => {
    let adminActions = '';
    if (b.status === 'Menunggu Verifikasi') {
      if (b.applicantType === 'Internal USK') {
        adminActions = `
          <button onclick="adminChangeStatus('${b.id}', 'Booked')" class="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition">Setujui Disposisi (Langsung Booked)</button>
          <button onclick="adminChangeStatus('${b.id}', 'Ditolak')" class="px-3 py-1.5 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-bold transition">Tolak</button>
        `;
      } else {
        adminActions = `
          <button onclick="adminChangeStatus('${b.id}', 'Menunggu Pembayaran')" class="px-3 py-1.5 rounded-lg bg-[#2B6CB0] hover:bg-[#1A365D] text-white text-xs font-bold transition">Setujui & tindak lanjuti offline</button>
          <button onclick="adminChangeStatus('${b.id}', 'Ditolak')" class="px-3 py-1.5 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-bold transition">Tolak</button>
        `;
      }
    } else if (b.status === 'Menunggu Pembayaran') {
      adminActions = `
        <button onclick="adminChangeStatus('${b.id}', 'Booked')" class="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition">Konfirmasi pembayaran di luar situs</button>
        <button onclick="adminChangeStatus('${b.id}', 'Ditolak')" class="px-3 py-1.5 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-bold transition">Batalkan</button>
      `;
    } else if (b.status === 'Booked') {
      adminActions = `
        <button onclick="openReservationSummary('${b.id}')" class="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition">Lihat Ringkasan</button>
      `;
    }

    return `
      <div class="p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
        <div class="space-y-1">
          <div class="flex flex-wrap items-center gap-2">
            <span class="text-xs font-mono font-bold text-[#1A365D]">${b.id}</span>
            <span class="text-[11px] px-2 py-0.5 rounded font-semibold bg-white border border-slate-200">${b.applicantType}</span>
            <span class="text-[11px] px-2 py-0.5 rounded font-bold ${
              b.status === 'Booked' ? 'bg-emerald-100 text-emerald-800' :
              b.status === 'Ditolak' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
            }">${b.status}</span>
          </div>
          <div class="font-bold text-sm text-slate-800">${b.eventName}</div>
          <div class="text-xs text-slate-600">${b.orgName} • <strong>${formatDateID(b.date)}</strong> (${b.durationText})</div>
          <div class="text-xs text-slate-500">Paket: ${b.packageName} • <strong class="text-[#1A365D]">${formatRupiah(b.totalCost)}</strong></div>
        </div>
        <div class="flex flex-wrap gap-2 shrink-0">${adminActions}</div>
      </div>
    `;
  }).join('');

  // Render Blocked Campus Dates
  const blockedContainer = document.getElementById('blocked-dates-list');
  const blockedItems = bookings.filter(b => b.isCampusBlock);
  blockedContainer.innerHTML = blockedItems.map(b => `
    <div class="p-2.5 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-between gap-2">
      <div>
        <div class="font-bold text-rose-900">${formatDateID(b.date)} (${b.durationText})</div>
        <div class="text-rose-700">${b.eventName}</div>
      </div>
      <button onclick="removeCampusBlock('${b.id}')" class="text-rose-600 hover:text-rose-900 font-bold px-2 py-1" title="Hapus Blokir">✕</button>
    </div>
  `).join('');
}

function adminChangeStatus(id, newStatus) {
  const b = bookings.find(item => item.id === id);
  if (!b) return;
  b.status = newStatus;
  if (newStatus === 'Booked' && !b.paymentProof) {
    b.paymentProof = b.applicantType === 'Internal USK' ? 'Disetujui Admin BUK' : 'Tervalidasi Manual Admin';
  }
  updateNavBadges();
  renderAdminDashboard();
  showToast(`Status pengajuan #${id} diperbarui menjadi: ${newStatus}`, 'info');
}

function blockCampusDate(e) {
  e.preventDefault();
  const dateVal = document.getElementById('block-date-input').value;
  const titleVal = document.getElementById('block-title-input').value.trim();

  const blockEntry = {
    id: `USK-${Date.now().toString().slice(-4)}`,
    eventName: titleVal,
    orgName: 'Universitas Syiah Kuala (Agenda Resmi)',
    applicantType: 'Internal USK',
    category: 'Wisuda',
    packageName: 'Seluruh Zona Gedung AAC Dayan Dawood',
    zones: [...ALL_ZONES],
    date: dateVal,
    days: 1,
    durationText: '1 Hari',
    totalCost: 0,
    status: 'Booked',
    fileName: 'Kalender_Akademik_USK.pdf',
    paymentProof: 'Agenda Resmi Universitas',
    isCampusBlock: true
  };

  bookings.unshift(blockEntry);
  document.getElementById('block-title-input').value = '';
  selectedDateStr = dateVal;
  renderAdminDashboard();
  showToast(`Tanggal ${formatDateID(dateVal)} berhasil dikunci di kalender publik!`, 'warning');
}

function removeCampusBlock(id) {
  bookings = bookings.filter(b => b.id !== id);
  renderAdminDashboard();
  showToast('Blokir jadwal kampus dihapus.', 'info');
}

function updateNavBadges() {
  const count = bookings.filter(b => !b.isCampusBlock).length;
  document.getElementById('badge-pemohon-count').textContent = count;
}

// ==================== RESERVATION SUMMARY ====================
function openReservationSummary(id) {
  const b = bookings.find(item => item.id === id);
  if (!b) return;

  const body = document.getElementById('reservation-modal-body');
  body.innerHTML = `
    <div class="flex items-center justify-between bg-emerald-50 border border-emerald-200 rounded-xl p-3">
      <div class="text-xs">
        <div class="text-emerald-800 font-bold">STATUS: TERKONFIRMASI (BOOKED)</div>
        <div class="text-emerald-700">Kode Booking: <strong>#${b.id}</strong></div>
      </div>
      <div class="shrink-0 rounded-lg border border-emerald-200 bg-white px-3 py-2 text-center">
        <span class="block text-[9px] font-bold uppercase tracking-wider text-slate-400">Kode Booking</span>
        <strong class="font-mono text-sm text-[#1A365D]">#${b.id}</strong>
      </div>
    </div>

    <div class="space-y-2.5 text-xs">
      <div class="border-b border-slate-100 pb-2">
        <span class="text-slate-400 block">Nama Kegiatan</span>
        <strong class="text-sm text-[#1A365D]">${b.eventName}</strong>
      </div>
      <div class="grid grid-cols-2 gap-2 border-b border-slate-100 pb-2">
        <div>
          <span class="text-slate-400 block">Penyelenggara</span>
          <strong class="text-slate-800">${b.orgName}</strong>
        </div>
        <div>
          <span class="text-slate-400 block">Kategori</span>
          <strong class="text-slate-800">${b.applicantType}</strong>
        </div>
      </div>
      <div class="border-b border-slate-100 pb-2">
        <span class="text-slate-400 block">Paket & Zona Ruangan</span>
        <strong class="text-slate-800">${b.packageName}</strong>
        <div class="text-[11px] text-slate-500 mt-0.5">Zona: ${b.zones.join(', ')}</div>
      </div>
      <div class="grid grid-cols-2 gap-2">
        <div>
          <span class="text-slate-400 block">Tanggal & Durasi</span>
          <strong class="text-slate-800">${formatDateID(b.date)} (${b.durationText})</strong>
        </div>
        <div>
          <span class="text-slate-400 block">Total Nilai Tarif</span>
          <strong class="text-[#1A365D]">${formatRupiah(b.totalCost)}</strong>
        </div>
      </div>
    </div>
  `;

  document.getElementById('reservation-modal').classList.remove('hidden');
}

function closeReservationSummary() {
  document.getElementById('reservation-modal').classList.add('hidden');
}

// ==================== INITIALIZATION ====================
window.addEventListener('DOMContentLoaded', () => {
  const siteHeader = document.querySelector('.site-header');
  const updateHeaderState = () => {
    siteHeader.classList.toggle('is-scrolled', window.scrollY > 24);
  };
  updateHeaderState();
  window.addEventListener('scroll', updateHeaderState, { passive: true });

  const revealElements = document.querySelectorAll('.scroll-reveal');
  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.14, rootMargin: '0px 0px -32px 0px' });
    revealElements.forEach(element => revealObserver.observe(element));
  } else {
    revealElements.forEach(element => element.classList.add('is-visible'));
  }

  document.getElementById('form-date').value = '2026-11-25';
  document.getElementById('block-date-input').value = '2026-11-28';
  renderCalendar();
  renderPricelist('ALL');
  onCategoryChange();
  updateNavBadges();
});
