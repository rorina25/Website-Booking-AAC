tailwind.config = {
  theme: {
    extend: {
      fontFamily: {
        sans: ['Plus Jakarta Sans', 'sans-serif'],
      },
      colors: {
        usk: {
          navy: '#003161',
          royal: '#0045B3',
          gold: '#FFBC23',
          goldLight: '#FFF5D6',
          surface: '#F1F7FD',
        }
      }
    }
  }
}
