// 1. MASTER DATA: 8 ZONA GEDUNG AAC DAYAN DAWOOD
const ALL_ZONES = [
  'Event Hall',
  'Lobby Bawah',
  'Lobby Atas',
  'Lobby VIP',
  'Ruang VIP',
  'Flamboyan Lt. II',
  'Flamboyan Lt. III',
  'Area Luar Gedung'
];

// 2. MASTER DATA: PRICELIST RESMI (5 KATEGORI)
const PRICELIST_DATA = [
  // A. Kegiatan Seminar
  { id: 'SEM-1', category: 'Seminar', categoryLabel: 'A. Kegiatan Seminar', name: 'Ruang Event Hall + Lobby Bawah', unit: 'Hari', price: 8500000, zones: ['Event Hall', 'Lobby Bawah'] },
  { id: 'SEM-2', category: 'Seminar', categoryLabel: 'A. Kegiatan Seminar', name: 'Lobby VIP', unit: 'Hari', price: 1000000, zones: ['Lobby VIP'] },
  { id: 'SEM-3', category: 'Seminar', categoryLabel: 'A. Kegiatan Seminar', name: 'Ruang VIP', unit: 'Hari', price: 4000000, zones: ['Ruang VIP'] },
  { id: 'SEM-4', category: 'Seminar', categoryLabel: 'A. Kegiatan Seminar', name: 'Flamboyan Lantai II', unit: 'Hari', price: 1000000, zones: ['Flamboyan Lt. II'] },
  { id: 'SEM-5', category: 'Seminar', categoryLabel: 'A. Kegiatan Seminar', name: 'Flamboyan Lantai III', unit: 'Hari', price: 3500000, zones: ['Flamboyan Lt. III'] },

  // B. Kegiatan Resepsi
  { id: 'RES-1', category: 'Resepsi', categoryLabel: 'B. Kegiatan Resepsi', name: 'Paket I (Ruang Event Hall + Lobby Bawah + Lobby VIP + Ruang VIP)', unit: 'Hari', price: 18000000, zones: ['Event Hall', 'Lobby Bawah', 'Lobby VIP', 'Ruang VIP'] },
  { id: 'RES-2', category: 'Resepsi', categoryLabel: 'B. Kegiatan Resepsi', name: 'Paket II (Ruang Event Hall + Lobby Bawah + Lobby VIP)', unit: 'Hari', price: 15000000, zones: ['Event Hall', 'Lobby Bawah', 'Lobby VIP'] },
  { id: 'RES-3', category: 'Resepsi', categoryLabel: 'B. Kegiatan Resepsi', name: 'Paket III (Ruang Event Hall + Lobby Bawah)', unit: 'Hari', price: 12000000, zones: ['Event Hall', 'Lobby Bawah'] },

  // C. Kegiatan Pameran
  { id: 'PAM-1', category: 'Pameran', categoryLabel: 'C. Kegiatan Pameran', name: 'Ruang Event Hall', unit: 'Hari', price: 7000000, zones: ['Event Hall'] },
  { id: 'PAM-2', category: 'Pameran', categoryLabel: 'C. Kegiatan Pameran', name: 'Lobby Bawah', unit: 'Hari', price: 3300000, zones: ['Lobby Bawah'] },
  { id: 'PAM-3', category: 'Pameran', categoryLabel: 'C. Kegiatan Pameran', name: 'Lobby Atas', unit: 'Hari', price: 2200000, zones: ['Lobby Atas'] },
  { id: 'PAM-4', category: 'Pameran', categoryLabel: 'C. Kegiatan Pameran', name: 'Lobby VIP', unit: 'Hari', price: 2750000, zones: ['Lobby VIP'] },
  { id: 'PAM-5', category: 'Pameran', categoryLabel: 'C. Kegiatan Pameran', name: 'Ruang VIP', unit: 'Hari', price: 4000000, zones: ['Ruang VIP'] },
  { id: 'PAM-6', category: 'Pameran', categoryLabel: 'C. Kegiatan Pameran', name: 'Pemasangan di Luar Gedung', unit: 'Hari', price: 2000000, zones: ['Area Luar Gedung'] },

  // D. Kegiatan Wisuda
  { id: 'WIS-1', category: 'Wisuda', categoryLabel: 'D. Kegiatan Wisuda', name: 'Paket I (Ruang Event Hall + Lobby Bawah + Lobby VIP + Ruang VIP)', unit: 'Hari', price: 15000000, zones: ['Event Hall', 'Lobby Bawah', 'Lobby VIP', 'Ruang VIP'] },
  { id: 'WIS-2', category: 'Wisuda', categoryLabel: 'D. Kegiatan Wisuda', name: 'Paket II (Ruang Event Hall + Lobby Bawah + Lobby VIP)', unit: 'Hari', price: 12000000, zones: ['Event Hall', 'Lobby Bawah', 'Lobby VIP'] },
  { id: 'WIS-3', category: 'Wisuda', categoryLabel: 'D. Kegiatan Wisuda', name: 'Paket III (Ruang Event Hall + Lobby Bawah)', unit: 'Hari', price: 10000000, zones: ['Event Hall', 'Lobby Bawah'] },

  // E. Komersil (Konser)
  { id: 'KON-ALL', category: 'Komersil', categoryLabel: 'E. Komersil (Konser)', name: 'Event Hall + Lobby Bawah + Lobby VIP', unit: 'Jam (H-1 & Hari-H)', priceH1: 1000000, priceDay: 1500000, zones: ['Event Hall', 'Lobby Bawah', 'Lobby VIP'], isConcert: true }
];

// 3. STATE FRONTEND (PENYIMPANAN SERVER BELUM TERHUBUNG)
let currentYear = 2026;
let currentMonth = 10; // 0-indexed: 10 = November 2026
let selectedDateStr = '2026-11-18';

// Contoh jadwal dan pengajuan untuk menampilkan antarmuka sebelum data server tersedia.
let bookings = [
  {
    id: 'BK-2026-001',
    eventName: 'Wisuda Sarjana & Pascasarjana USK Periode IV',
    orgName: 'Biro Akademik Universitas Syiah Kuala',
    applicantType: 'Internal USK',
    category: 'Wisuda',
    packageName: 'Paket I (Ruang Event Hall + Lobby Bawah + Lobby VIP + Ruang VIP)',
    zones: ['Event Hall', 'Lobby Bawah', 'Lobby VIP', 'Ruang VIP'],
    date: '2026-11-11',
    days: 2, // 11 & 12 Nov
    durationText: '2 Hari (11 - 12 Nov 2026)',
    totalCost: 30000000,
    status: 'Booked', // 'Menunggu Verifikasi' | 'Menunggu Pembayaran' | 'Booked' | 'Ditolak'
    fileName: 'SK_Rektor_Wisuda_IV_2026.pdf',
    paymentProof: 'Disposisi Internal USK',
    isCampusBlock: true
  },
  {
    id: 'BK-2026-002',
    eventName: 'Aceh Tech & Innovation Expo 2026',
    orgName: 'Ikatan Alumni Teknik USK',
    applicantType: 'Eksternal / Umum',
    category: 'Pameran',
    packageName: 'Ruang Event Hall',
    zones: ['Event Hall'],
    date: '2026-11-18',
    days: 1,
    durationText: '1 Hari',
    totalCost: 7000000,
    status: 'Booked',
    fileName: 'Surat_Permohonan_Alumni_FT.pdf',
    paymentProof: 'Bukti_Transfer_BSI_7jt.pdf',
    isCampusBlock: false
  },
  {
    id: 'BK-2026-003',
    eventName: 'Seminar Nasional Kewirausahaan Mahasiswa',
    orgName: 'BEM Universitas Syiah Kuala',
    applicantType: 'Internal USK',
    category: 'Seminar',
    packageName: 'Flamboyan Lantai III',
    zones: ['Flamboyan Lt. III'],
    date: '2026-11-18',
    days: 1,
    durationText: '1 Hari',
    totalCost: 3500000,
    status: 'Menunggu Verifikasi',
    fileName: 'Surat_Izin_BEM_USK.pdf',
    paymentProof: null,
    isCampusBlock: false
  },
  {
    id: 'BK-2026-004',
    eventName: 'Resepsi Pernikahan Keluarga Besar H. Sulaiman',
    orgName: 'dr. Cut Meutia Sari',
    applicantType: 'Eksternal / Umum',
    category: 'Resepsi',
    packageName: 'Paket II (Ruang Event Hall + Lobby Bawah + Lobby VIP)',
    zones: ['Event Hall', 'Lobby Bawah', 'Lobby VIP'],
    date: '2026-11-22',
    days: 1,
    durationText: '1 Hari',
    totalCost: 15000000,
    status: 'Menunggu Pembayaran',
    fileName: 'Permohonan_Sewa_Resepsi.pdf',
    paymentProof: null,
    isCampusBlock: false
  }
];
